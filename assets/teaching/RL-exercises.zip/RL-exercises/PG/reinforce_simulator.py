# References:
# R. J. Williams, "Simple statistical gradient-following algorithms for connectionist reinforcement learning",
# Machine Learning 8, 229-256, 1992. REINFORCE: Section 4, p. 234; episodic REINFORCE: Section 5, Eq. (11), p. 237;
# Gaussian units: Section 6.
# R. S. Sutton and A. G. Barto, "Reinforcement Learning: An Introduction", 2nd ed., MIT Press, 2018. REINFORCE: Section 13.3.

import sys

from reinforce import Policy_Network, MultivariateNormal, torch, gym, device
		
		
class PGAS():

	def __init__(self, env_name, network):
		self.env_name = env_name
		self.env = gym.make(self.env_name, continuous = True)
		self.action_size = self.env.action_space.shape[0]
		self.state_size = self.env.observation_space.shape[0]
		self.env.close()
		
		self.model = network(self.state_size, self.action_size).to(device)
		
		self.I = torch.eye(self.action_size).to(device)
			
	def select_action(self, state):		
		with torch.no_grad():
			means, variances = self.model(state.unsqueeze(0))
			m = MultivariateNormal(means, self.I*variances)
			a = m.sample().squeeze()
			return a
			
	
	def load_model(self, path=""):
		self.model.load_state_dict(torch.load(path+self.env_name+"_PGA_Reinforce.pt", map_location=torch.device(device)))
		self.model.eval()


	def simulate(self):
		env = gym.make(self.env_name, continuous = True, render_mode = "human")
		done = False
		state, _ = env.reset()
		# gymnasium gives 0.4 times the angular velocity: the factor converts it to rad/s
		state[5] *= 2.5
		state = torch.tensor(state).to(device)
		while not done:
			action = self.select_action(state)
			next_state, _, terminated, truncated, _ = env.step(action.cpu().numpy())

			done = terminated or truncated

			# gymnasium gives 0.4 times the angular velocity: the factor converts it to rad/s
			next_state[5] *= 2.5
			state = torch.tensor(next_state).to(device)

		env.close()

if __name__ == '__main__':

	network = Policy_Network
	models_path = "models/"
		
	if len(sys.argv) > 1:
		num_simulations = int(sys.argv[1])
	else:
		num_simulations = 1
	
	env = 'LunarLander-v3'

	agent = PGAS(env, network)
	agent.load_model(models_path)
	
	for i in range(num_simulations):
		agent.simulate()
