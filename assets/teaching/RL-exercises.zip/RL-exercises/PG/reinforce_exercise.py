# References:
# R. J. Williams, "Simple statistical gradient-following algorithms for connectionist reinforcement learning",
# Machine Learning 8, 229-256, 1992. REINFORCE: Section 4, p. 234; episodic REINFORCE: Section 5, Eq. (11), p. 237;
# Gaussian units: Section 6.
# R. S. Sutton and A. G. Barto, "Reinforcement Learning: An Introduction", 2nd ed., MIT Press, 2018. REINFORCE: Section 13.3.

import gymnasium as gym
import math, random
import numpy as np
import matplotlib.pyplot as plt
from tqdm import tqdm
import os

# on Apple silicon, the operations that the GPU does not support run on the CPU
os.environ.setdefault("PYTORCH_ENABLE_MPS_FALLBACK", "1")

import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.distributions.multivariate_normal import MultivariateNormal

from multiprocessing import cpu_count

######## SET DEVICE ######################
# use the GPU when available: NVIDIA or AMD (cuda), Intel (xpu) or Apple silicon (mps), otherwise the CPU
if torch.cuda.is_available():
	device = "cuda:0"
elif torch.xpu.is_available():
	device = "xpu"
elif torch.backends.mps.is_available():
	device = "mps"
else:
	device = "cpu"

# back to the CPU if the Intel GPU cannot run the operations of the exercise
if device == "xpu":
	try:
		layer = nn.Linear(8, 2).to(device)
		m = MultivariateNormal(layer(torch.randn((4, 8)).to(device)), torch.eye(2).to(device))
		m.log_prob(m.sample()).sum().backward()
	except Exception:
		print("the Intel GPU failed a test operation: the CPU is used instead")
		device = "cpu"
#########################################

class Policy_Network(nn.Module):

	def __init__(self, in_size, out_size, hidden = 64):
		super().__init__()
		self.layer1 = nn.Linear(in_size, hidden)
		self.layer2 = nn.Linear(hidden, hidden)
		self.layer3 = nn.Linear(hidden, out_size*2)

		self.out_size = out_size
		
		# means: main engine in (-0.5, 1), lateral engine in (-1, 1), as the engines of LunarLander require
		self.scale_factor = torch.tensor([1.5, 2], requires_grad = False).to(device)
		self.bias_factor = torch.tensor([- 0.5, -1], requires_grad = False).to(device)

	def forward(self, x):
		x = F.relu(self.layer1(x))
		x = F.relu(self.layer2(x))
		x = F.sigmoid(0.5*self.layer3(x))
		# means of the actions, and variances: the diagonal of the covariance matrix
		return x[:, :self.out_size] * self.scale_factor + self.bias_factor, x[:, self.out_size:] + 0.01

		
	def __str__(self):
		return "PG"
		
		
class PGA_Reinforce():

	def __init__(self, env, n_updates, gamma, learning_rate, network, traj_batch_size, early_stopping_window, threshold, seed):
		self.env_name = env
		self.seed = seed
		self.env = gym.make(self.env_name, continuous = True)
		self.env.reset(seed = self.seed)
		self.n_updates = n_updates
		self.gamma = gamma
		
		self.score = []
		self.var_main = []
		self.var_sec = []
		self.var_main_avg = []
		self.var_sec_avg = []
		
		self.traj_batch_size = traj_batch_size
		# the window is given in episodes and converted to updates
		self.early_stopping_window = math.ceil(early_stopping_window/traj_batch_size)
		self.threshold = threshold
		
		self.action_size = self.env.action_space.shape[0]
		self.state_size = self.env.observation_space.shape[0]
		
		self.learning_rate = learning_rate
		
		self.memory_state = []
		self.memory_action = []
		self.memory_reward = []
		
		self.model = network(self.state_size, self.action_size).to(device)
		self.model.eval()
		
		self.optimizer = optim.AdamW(self.model.parameters(), lr = learning_rate, amsgrad=True)
		
		self.I = torch.eye(self.action_size).to(device)
		
		
	def reset_agent(self):
		self.memory_state = []
		self.memory_action = []
		self.memory_reward = []
		
			
	def add_experience(self, state, action, reward):
		raise NotImplementedError # TODO add the transition at the front of the current trajectory


	def select_action(self, state):
		with torch.no_grad():
			raise NotImplementedError # TODO predict the distribution parameters according to the state
			self.var_main.append(variances[:, 0].cpu().numpy())
			self.var_sec.append(variances[:, 1].cpu().numpy())
			m = MultivariateNormal(means, self.I*variances)
			raise NotImplementedError # TODO sample the action "a" from the distribution
			a = a.squeeze()
			return a
	
	
	def experience_replay(self):
		
		raise NotImplementedError # TODO turn each trajectory in a tensor
		raise NotImplementedError # TODO compute the return for each action taken, in place of its reward
					
		
		state_batch = torch.vstack(self.memory_state)
		action_batch = torch.vstack(self.memory_action)
		return_batch = torch.hstack(self.memory_reward)
			

		self.model.train()
		
		raise NotImplementedError # TODO predict the distribution parameters according to the batch state
		m = MultivariateNormal(means, torch.einsum('ij, jh -> ijh', variances, self.I))
		raise NotImplementedError # TODO compute the log likelihood of each action according to the distribution it has been drawn from

		# REINFORCE without baseline
		raise NotImplementedError # TODO policy gradient loss
		
		self.optimizer.zero_grad()
		loss.mean().backward()
		self.optimizer.step()
		
		self.model.eval()
		

	def learn(self):
		bar = tqdm(np.arange(self.n_updates), desc="Learning")
		for e in bar:
		
			score = 0.0
			
			if len(self.score) >= self.early_stopping_window and np.mean(self.score[-self.early_stopping_window:]) >= self.threshold:
				break
		
			for t in np.arange(self.traj_batch_size):
				
				state, _ = self.env.reset()
				# gymnasium gives 0.4 times the angular velocity: the factor converts it to rad/s
				state[5] *= 2.5
				state = torch.tensor(state).to(device)
				episode_score = 0.0
				done = False
				raise NotImplementedError # TODO prepare the memory for a new trajectory
							
				while not done:

					action = self.select_action(state)

					next_state, reward, terminated, truncated, _ = self.env.step(action.cpu().numpy())
					
					done = terminated or truncated
					
					# gymnasium gives 0.4 times the angular velocity: the factor converts it to rad/s
					next_state[5] *= 2.5
					next_state = torch.tensor(next_state).to(device)

					episode_score += reward
					reward = torch.tensor(reward, dtype = torch.float32).to(device)
					
					self.add_experience(state, action, reward)
					
					state = next_state	
			
				score += (episode_score - score)/(t+1)
			
			self.var_main_avg.append(np.mean(self.var_main))
			self.var_sec_avg.append(np.mean(self.var_sec))
			self.var_main = []
			self.var_sec = []
			
			self.score.append(score)
			self.experience_replay()	
			self.reset_agent()

			bar.set_postfix({'Score': f'{score:.0f}', 'Var Main': f'{self.var_main_avg[-1]:.2f}', 'Var Sec': f'{self.var_sec_avg[-1]:.2f}'})
					
		self.env.close()
		
		
	def plot_learning(self, N, title=None, filename = ""):
		plt.plot(self.score, label = "score")
		if len(self.score) >= N:
			mean_score = np.convolve(np.array(self.score), np.ones(N)/N, mode='valid')
			plt.plot(np.arange(len(mean_score)) + (N - 1) // 2, mean_score, label = "moving average")
		plt.xlabel("update")
		plt.ylabel("mean score of the batch")
		plt.legend()

		if title is not None:
			plt.title(title);

		plt.savefig(filename + "_" + self.env_name)
		plt.clf()
		
	def plot_variance(self, title=None, filename = ""):
		plt.plot(self.var_main_avg, label="main");
		plt.plot(self.var_sec_avg, label="secondary");
		plt.xlabel("update")
		plt.ylabel("mean variance")
		plt.legend()

		if title is not None:
			plt.title(title);

		plt.savefig(filename + "_" + self.env_name)
		plt.clf()
		
	
	def save_model(self, path=""):
		torch.save(self.model.state_dict(), path+self.env_name+"_"+str(self)+".pt")

	
	def load_model(self, path):
		self.model.load_state_dict(torch.load(path+self.env_name+"_"+str(self)+".pt", map_location=torch.device(device)))
		self.model.eval()
		
	
	def __str__(self):
		return "PGA_Reinforce"


if __name__ == '__main__':

	######## SET PARALLEL COMPUTING ##########
	num_cores = cpu_count()

	torch.set_num_interop_threads(num_cores) # Inter-op parallelism
	torch.set_num_threads(num_cores) # Intra-op parallelism
	##########################################

	######### SET SEED ######################
	seed = 1
	np.random.seed(seed)
	random.seed(seed)
	torch.manual_seed(seed)
	torch.cuda.manual_seed(seed)
	torch.backends.cudnn.deterministic = True
	torch.backends.cudnn.benchmark = False
	#########################################

	env = 'LunarLander-v3'
	network = Policy_Network
	# number of updates; each update uses traj_batch_size episodes
	n_updates = 350
	gamma = 0.99
	learning_rate = 1e-2
	early_stopping_window = 50
	threshold = 200
	traj_batch_size = 15
	imgs_path = "imgs/"
	models_path = "models/"
	
	os.makedirs(imgs_path, exist_ok = True)
	os.makedirs(models_path, exist_ok = True)

	agent = PGA_Reinforce(env, n_updates, gamma, learning_rate, network, traj_batch_size, early_stopping_window, threshold, seed)
	
	agent.learn()
	agent.save_model(models_path)
	agent.plot_learning(31, title = "Lunar Lander", filename = imgs_path + str(agent))
	agent.plot_variance(title = "Lunar Lander variance", filename = imgs_path + str(agent)+"_variance")
