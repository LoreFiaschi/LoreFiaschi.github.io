# Reference: T. P. Lillicrap, J. J. Hunt, A. Pritzel, N. Heess, T. Erez, Y. Tassa, D. Silver, D. Wierstra,
# "Continuous control with deep reinforcement learning", ICLR 2016.
# DDPG: Algorithm 1, p. 5.

import gymnasium as gym
import random, os
import numpy as np
import matplotlib.pyplot as plt
from tqdm import tqdm
from collections import deque

# on Apple silicon, the operations that the GPU does not support run on the CPU
os.environ.setdefault("PYTORCH_ENABLE_MPS_FALLBACK", "1")

import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F

from multiprocessing import cpu_count

######## SET DEVICE ######################
# use the GPU when available: NVIDIA or AMD (cuda), Intel (xpu) or Apple silicon (mps), otherwise the CPU
if torch.cuda.is_available():
	device = "cuda:0"
elif torch.xpu.is_available():
	device = "xpu"
elif torch.backends.mps.is_available():
	device = "mps"
else:
	device = "cpu"

# back to the CPU if the Intel GPU cannot run the operations of the exercise
if device == "xpu":
	try:
		layer = nn.Linear(8, 2).to(device)
		layer(torch.randn((4, 8)).to(device)).pow(2).mean().backward()
	except Exception:
		print("the Intel GPU failed a test operation: the CPU is used instead")
		device = "cpu"
#########################################


class Actor_Network(nn.Module):

	def __init__(self, n_observations, n_actions, hidden = 64):
		super().__init__()
		self.layer1 = nn.Linear(n_observations, hidden)
		self.layer2 = nn.Linear(hidden, hidden)
		self.layer3 = nn.Linear(hidden, n_actions)

	def forward(self, x):
		x = F.relu(self.layer1(x))
		x = F.relu(self.layer2(x))
		return torch.tanh(self.layer3(x))


class Critic_Network(nn.Module):

	def __init__(self, n_observations, n_actions, hidden = 64):
		super().__init__()
		self.layer1 = nn.Linear(n_observations + n_actions, hidden)
		self.layer2 = nn.Linear(hidden, hidden)
		self.layer3 = nn.Linear(hidden, 1)

	def forward(self, x, a):
		x = F.relu(self.layer1(torch.cat((x, a), dim = 1)))
		x = F.relu(self.layer2(x))
		return self.layer3(x)


class DDPGA():

	def __init__(self, env, noise_start, noise_decay, noise_min, episodes, gamma, actor_learning_rate, critic_learning_rate, batch_size,
					train_start, replay_frequency, target_model_update_rate, memory_length, mini_batches, early_stopping_window, threshold):
		self.env_name = env
		self.env = gym.make(self.env_name, continuous = True)
		self.noise_std = noise_start
		self.noise_decay = noise_decay
		self.noise_min = noise_min
		self.episodes = episodes
		self.gamma = gamma
		self.actor_learning_rate = actor_learning_rate
		self.critic_learning_rate = critic_learning_rate
		self.batch_size = batch_size
		self.train_start = train_start
		self.replay_frequency = replay_frequency
		self.target_model_update_rate = target_model_update_rate
		self.memory_length = memory_length
		self.mini_batches = mini_batches
		self.early_stopping_window = early_stopping_window
		self.threshold = threshold
		self.score = []
		self.noise_record = []

		self.action_size = self.env.action_space.shape[0]
		self.state_size = self.env.observation_space.shape[0]

		self.memory = deque(maxlen=self.memory_length)

		self.actor = Actor_Network(self.state_size, self.action_size).to(device)
		self.target_actor = Actor_Network(self.state_size, self.action_size).to(device)
		self.critic = Critic_Network(self.state_size, self.action_size).to(device)
		self.target_critic = Critic_Network(self.state_size, self.action_size).to(device)

		self.target_actor.load_state_dict(self.actor.state_dict())
		self.target_critic.load_state_dict(self.critic.state_dict())
		self.actor.eval()
		self.target_actor.eval()
		self.critic.eval()
		self.target_critic.eval()

		self.criterion = nn.SmoothL1Loss()
		self.actor_optimizer = optim.AdamW(self.actor.parameters(), lr = self.actor_learning_rate, amsgrad=True)
		self.critic_optimizer = optim.AdamW(self.critic.parameters(), lr = self.critic_learning_rate, amsgrad=True)

		self.state_batch = torch.empty((self.batch_size, self.state_size)).to(device)
		self.action_batch = torch.empty((self.batch_size, self.action_size)).to(device)
		self.reward_batch = torch.empty((self.batch_size, 1)).to(device)
		self.next_state_batch = torch.empty((self.batch_size, self.state_size)).to(device)
		self.not_done_batch = torch.empty(self.batch_size, dtype = torch.bool).to(device)


	def update_noise(self):
		if len(self.memory) >= self.train_start and self.noise_std > self.noise_min:
			self.noise_std *= self.noise_decay


	def add_experience(self, state, action, reward, next_state, done):
		self.memory.append((state, action, reward, next_state, done))


	def select_action(self, state):
		with torch.no_grad():
			raise NotImplementedError # TODO deterministic action of the actor
			raise NotImplementedError # TODO exploration noise
			return torch.clamp(action, -1, 1)


	def update_target_model(self, tau):
		for model, target_model in zip([self.actor, self.critic], [self.target_actor, self.target_critic]):
			weights = model.state_dict()
			target_weights = target_model.state_dict()
			for i in target_weights:
				raise NotImplementedError # TODO soft update
			target_model.load_state_dict(target_weights)


	def q_value_arrival_state(self, states):
		raise NotImplementedError # TODO q value of the arrival state according to the target models


	def experience_replay(self):
		if len(self.memory) < self.train_start:
			return

		batch = random.sample(self.memory, self.batch_size)

		for i in np.arange(self.batch_size):
			self.state_batch[i,:] = batch[i][0]
			self.action_batch[i,:] = batch[i][1]
			self.reward_batch[i,0] = batch[i][2]
			self.next_state_batch[i,:] = batch[i][3]
			self.not_done_batch[i] = not batch[i][4]

		next_state_values = torch.zeros((self.batch_size, 1)).to(device)

		with torch.no_grad():
			next_state_values[self.not_done_batch] = self.q_value_arrival_state(self.next_state_batch[self.not_done_batch,:])
			raise NotImplementedError # TODO compute the target according to the TD(0) paradigm

		self.actor.train()
		self.critic.train()

		# update the critic
		raise NotImplementedError # TODO compute the q value according to the critic

		critic_loss = self.criterion(predicted_values, target_values)

		self.critic_optimizer.zero_grad()
		critic_loss.backward()
		self.critic_optimizer.step()

		# update the actor
		raise NotImplementedError # TODO deterministic policy gradient loss

		self.actor_optimizer.zero_grad()
		actor_loss.backward()
		self.actor_optimizer.step()

		self.actor.eval()
		self.critic.eval()

		# update the target models
		self.update_target_model(self.target_model_update_rate)


	def learn(self):
		bar = tqdm(np.arange(self.episodes), desc="Learning")
		for e in bar:

			if len(self.score) >= self.early_stopping_window and np.mean(self.score[-self.early_stopping_window:]) >= self.threshold:
				break

			state, _ = self.env.reset()
			# gymnasium gives 0.4 times the angular velocity: the factor converts it to rad/s
			state[5] *= 2.5
			state = torch.tensor(state).to(device)
			episode_score = 0
			step = 0
			done = False

			while not done:
				# choose the next action
				action = self.select_action(state)

				# do the chosen action
				next_state, reward, terminated, truncated, _ = self.env.step(action.cpu().numpy())

				done = terminated or truncated

				# gymnasium gives 0.4 times the angular velocity: the factor converts it to rad/s
				next_state[5] *= 2.5
				next_state = torch.tensor(next_state).to(device)

				episode_score += reward
				reward = torch.tensor(reward, dtype = torch.float32).to(device)

				self.add_experience(state, action, reward, next_state, terminated)

				state = next_state

				if step % self.replay_frequency == 0:
					for i in np.arange(self.mini_batches):
						self.experience_replay()

				step += 1

			self.update_noise()
			self.score.append(episode_score)
			self.noise_record.append(self.noise_std)

			bar.set_postfix({'Score': f'{self.score[-1]:.0f}'})

		self.env.close()


	def plot_learning(self, N, title=None, filename = ""):
		plt.plot(self.score, label = "score")
		if len(self.score) >= N:
			mean_score = np.convolve(np.array(self.score), np.ones(N)/N, mode='valid')
			plt.plot(np.arange(len(mean_score)) + (N-1)//2, mean_score, label = "moving average")
		plt.xlabel("episode")
		plt.ylabel("score")
		plt.legend()

		if title is not None:
			plt.title(title)

		plt.savefig(filename + self.env_name)
		plt.clf()


	def plot_noise(self, filename = ""):
		plt.plot(self.noise_record)
		plt.xlabel("episode")
		plt.ylabel("standard deviation")
		plt.title("Exploration noise decay")
		plt.savefig(filename + self.env_name + "_noise")
		plt.clf()


	def save_model(self, path=""):
		torch.save(self.actor.state_dict(), path + self.env_name + "_" + str(self) + "_actor.pt")
		torch.save(self.critic.state_dict(), path + self.env_name + "_" + str(self) + "_critic.pt")


	def load_model(self, path=""):
		self.actor.load_state_dict(torch.load(path + self.env_name + "_" + str(self) + "_actor.pt", map_location=torch.device(device)))
		self.critic.load_state_dict(torch.load(path + self.env_name + "_" + str(self) + "_critic.pt", map_location=torch.device(device)))
		self.target_actor.load_state_dict(self.actor.state_dict())
		self.target_critic.load_state_dict(self.critic.state_dict())
		self.actor.eval()
		self.critic.eval()


	def __str__(self):
		return "DDPG"



if __name__ == '__main__':

	######## SET PARALLEL COMPUTING ##########
	num_cores = cpu_count()

	torch.set_num_interop_threads(num_cores) # Inter-op parallelism
	torch.set_num_threads(num_cores) # Intra-op parallelism
	##########################################

	env = 'LunarLander-v3'
	episodes = 800
	replay_frequency = 4
	gamma = 0.99
	actor_learning_rate = 1e-4
	critic_learning_rate = 1e-3
	noise_start = 0.3
	noise_decay = 0.99
	noise_min = 0.05
	batch_size = 256
	train_start = 2000
	target_model_update_rate = 1e-3
	memory_length = 20000
	mini_batches = 4
	early_stopping_window = 100
	threshold = 200

	imgs_path = "imgs/"
	models_path = "models/"

	os.makedirs(imgs_path, exist_ok=True)
	os.makedirs(models_path, exist_ok=True)

	agent = DDPGA(env, noise_start, noise_decay, noise_min, episodes, gamma, actor_learning_rate, critic_learning_rate, batch_size,
				train_start, replay_frequency, target_model_update_rate, memory_length, mini_batches, early_stopping_window, threshold)

	agent.learn()
	agent.save_model(models_path)
	agent.plot_learning(31, title = "Lunar Lander", filename = imgs_path + str(agent) + "_")
	agent.plot_noise(imgs_path + str(agent) + "_")
