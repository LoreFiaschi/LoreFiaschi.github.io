# Reference: T. P. Lillicrap, J. J. Hunt, A. Pritzel, N. Heess, T. Erez, Y. Tassa, D. Silver, D. Wierstra,
# "Continuous control with deep reinforcement learning", ICLR 2016.
# DDPG: Algorithm 1, p. 5.

import sys

from DDPG import Actor_Network, torch, gym, device


class DDPGAS():

	def __init__(self, env_name):
		self.env_name = env_name
		self.env = gym.make(self.env_name, continuous = True)
		self.action_size = self.env.action_space.shape[0]
		self.state_size = self.env.observation_space.shape[0]
		self.env.close()

		self.actor = Actor_Network(self.state_size, self.action_size).to(device)


	def select_action(self, state):
		with torch.no_grad():
			return self.actor(state)


	def load_model(self, path=""):
		self.actor.load_state_dict(torch.load(path + self.env_name + "_DDPG_actor.pt", map_location=torch.device(device)))
		self.actor.eval()


	def simulate(self):
		env = gym.make(self.env_name, continuous = True, render_mode = "human")
		done = False
		state, _ = env.reset()
		# gymnasium gives 0.4 times the angular velocity: the factor converts it to rad/s
		state[5] *= 2.5
		state = torch.tensor(state).to(device)
		while not done:
			action = self.select_action(state)
			next_state, _, terminated, truncated, _ = env.step(action.cpu().numpy())

			done = terminated or truncated

			# gymnasium gives 0.4 times the angular velocity: the factor converts it to rad/s
			next_state[5] *= 2.5
			state = torch.tensor(next_state).to(device)

		env.close()


if __name__ == '__main__':

	models_path = "models/"

	if len(sys.argv) > 1:
		num_simulations = int(sys.argv[1])
	else:
		num_simulations = 1

	env = 'LunarLander-v3'

	agent = DDPGAS(env)
	agent.load_model(models_path)

	for i in range(num_simulations):
		agent.simulate()
