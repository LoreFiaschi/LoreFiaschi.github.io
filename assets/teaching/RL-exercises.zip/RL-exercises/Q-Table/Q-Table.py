# Reference: R. S. Sutton and A. G. Barto, "Reinforcement Learning: An Introduction", 2nd ed., MIT Press, 2018.
# SARSA: Section 6.4; Q-learning: Section 6.5; Expected SARSA: Section 6.6; cliff walking: Example 6.6.

import gymnasium as gym

from abc import ABC, abstractmethod
from tqdm import tqdm
import matplotlib.pyplot as plt

import numpy as np
import os, random

class tabular_agent(ABC):

    def __init__(self, env, epsilon_start, epsilon_decay, epsilon_min, episodes, gamma, learning_rate, max_episode_steps):
        self.env_name = env
        self.max_episode_steps = max_episode_steps
        self.env = gym.make(self.env_name, max_episode_steps = self.max_episode_steps)
        self.epsilon = epsilon_start
        self.epsilon_decay = epsilon_decay
        self.epsilon_min = epsilon_min
        self.episodes = episodes
        self.gamma = gamma
        self.learning_rate = learning_rate
        
        self.action_space = self.env.action_space
        self.action_size = self.env.action_space.n
        self.state_size = self.env.observation_space.n

        # Definition of the Q-table
        self.table = np.zeros((self.state_size, self.action_size))
        
        self.score = []
        self.epsilon_record = []

    def update_epsilon(self):
        if self.epsilon > self.epsilon_min:
            self.epsilon *= self.epsilon_decay

    @abstractmethod
    def update_table(self, state, action, reward, next_state, done):
        pass
    
    def select_action(self, state): # epsilon-greedy action selection
        if random.random() <= self.epsilon:
            return self.action_space.sample()
            
        return np.argmax(self.table[state, :])

    def learn(self):
        for e in tqdm(np.arange(self.episodes), desc="Learning"):
            state, _ = self.env.reset()
            episode_score = 0
            done = False
            
            while not done:
                # choose the next action
                action = self.select_action(state)
                
                # do the chosen action
                next_state, reward, terminated, truncated, _ = self.env.step(action)

                done = terminated or truncated

                # positive terminal state reached (the goal is the only terminal state)
                if terminated:
                    # reward of the goal set to +100 instead of the -1 of gymnasium
                    reward = 100

                episode_score += reward

                # learn
                self.update_table(state, action, reward, next_state, terminated)

                # update the current state
                state = next_state

                if done:
                    self.score.append(episode_score)
                    self.epsilon_record.append(self.epsilon)
                    self.update_epsilon()

    def plot_learning(self, N, title=None, filename=""):
        #plt.figure()
        plt.plot(self.score, label = "score");
        if len(self.score) >= N:
            mean_score = np.convolve(np.array(self.score), np.ones(N)/N, mode='valid')
            plt.plot(np.arange(len(mean_score)) + (N - 1) // 2, mean_score, label = "moving average");
        plt.xlabel("episode");
        plt.ylabel("score");
        plt.legend();
        if title is not None:
            plt.title(title);
        plt.savefig(filename + "_" + self.env_name, bbox_inches = "tight");
        plt.clf();

    def plot_epsilon(self, filename=""):
        plt.plot(self.epsilon_record);
        plt.xlabel("episode");
        plt.title("Epsilon decay");
        plt.savefig(filename + "_" + self.env_name + "_epsilon", bbox_inches = "tight");
        plt.clf();

    def save_table(self, path=""):
        np.save(path + self.env_name + "_" + str(self) + ".npy", self.table)


class Q_Learning(tabular_agent):

    def __init__(self, env, epsilon_start, epsilon_decay, epsilon_min, episodes, gamma, learning_rate, max_episode_steps):
        super().__init__(env, epsilon_start, epsilon_decay, epsilon_min, episodes, gamma, learning_rate, max_episode_steps)

    def update_table(self, state, action, reward, next_state, done):
        if done:
            self.table[state, action] += self.learning_rate * (reward - self.table[state, action])
        else:
            self.table[state, action] += self.learning_rate * (reward + self.gamma * np.max(self.table[next_state,:]) - self.table[state, action])

    def __str__(self):
        return "Q_Learning"


class SARSA(tabular_agent):

    def __init__(self, env, epsilon_start, epsilon_decay, epsilon_min, episodes, gamma, learning_rate, max_episode_steps):
        super().__init__(env, epsilon_start, epsilon_decay, epsilon_min, episodes, gamma, learning_rate, max_episode_steps)

    def update_table(self, state, action, reward, next_state, done):
        if done:
            self.table[state, action] += self.learning_rate * (reward - self.table[state, action])
        else:
            # the next action is sampled from the current policy (the action actually taken is chosen again after the update)
            self.table[state, action] += self.learning_rate * (reward + self.gamma * self.table[next_state, self.select_action(next_state)] - self.table[state, action])

    def __str__(self):
        return "SARSA"
            
class Expected_SARSA(tabular_agent):

    def __init__(self, env, epsilon_start, epsilon_decay, epsilon_min, episodes, gamma, learning_rate, max_episode_steps):
        super().__init__(env, epsilon_start, epsilon_decay, epsilon_min, episodes, gamma, learning_rate, max_episode_steps)

    def update_table(self, state, action, reward, next_state, done):
        if done:
            self.table[state, action] += self.learning_rate * (reward - self.table[state, action])
        else:
            self.table[state, action] += self.learning_rate * (reward + self.gamma * \
                                                               (self.epsilon * np.mean(self.table[next_state, :]) +\
                                                                (1-self.epsilon) * np.max(self.table[next_state, :])) \
                                                                - self.table[state, action])

    def __str__(self):
        return "Expected_SARSA"


if __name__ == '__main__':
    env = 'CliffWalking-v1'
    epsilon_start = 1.0
    epsilon_decay = 0.95
    epsilon_min = 0.01
    episodes = 200
    gamma = 0.99
    learning_rate = 0.3
    # time limit of an episode (CliffWalking-v1 has none)
    max_episode_steps = 200
    
    
    agent = Q_Learning(env, epsilon_start, epsilon_decay, epsilon_min, episodes, gamma, learning_rate, max_episode_steps)
    #agent = SARSA(env, epsilon_start, epsilon_decay, epsilon_min, episodes, gamma, learning_rate, max_episode_steps)
    #agent = Expected_SARSA(env, epsilon_start, epsilon_decay, epsilon_min, episodes, gamma, learning_rate, max_episode_steps)
    
    os.makedirs("imgs", exist_ok = True)
    os.makedirs("models", exist_ok = True)
    
    agent.learn()
    agent.save_table("models/")
    agent.plot_learning(11, filename = "imgs/" + str(agent))
    agent.plot_epsilon("imgs/" + str(agent))
