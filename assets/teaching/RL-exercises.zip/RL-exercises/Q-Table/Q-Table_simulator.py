# Reference: R. S. Sutton and A. G. Barto, "Reinforcement Learning: An Introduction", 2nd ed., MIT Press, 2018.
# SARSA: Section 6.4; Q-learning: Section 6.5; Expected SARSA: Section 6.6; cliff walking: Example 6.6.
# Every-visit Monte Carlo: Section 5.1; on-policy Monte Carlo control with epsilon-soft policies: Section 5.4.

import gymnasium as gym
import numpy as np
import sys


class Tabular_Simulator():

    def __init__(self, env_name, agent_type, max_episode_steps):
        self.env_name = env_name
        self.agent_type = agent_type
        self.max_episode_steps = max_episode_steps

    def select_action(self, state): # greedy action selection
        return np.argmax(self.table[state, :])

    def load_table(self, path=""):
        self.table = np.load(path + self.env_name + "_" + self.agent_type + ".npy")

    def simulate(self):
        env = gym.make(self.env_name, render_mode = "human", max_episode_steps = self.max_episode_steps)
        done = False
        state, _ = env.reset()
        while not done:
            action = self.select_action(state)
            next_state, _, terminated, truncated, _ = env.step(action)

            done = terminated or truncated

            state = next_state

        env.close()


if __name__ == '__main__':

    models_path = "models/"
    agent_types = ["Q_Learning", "SARSA", "Expected_SARSA", "MonteCarlo"]

    if len(sys.argv) > 1:
        agent_type = sys.argv[1]
    else:
        agent_type = "Q_Learning"

    if agent_type not in agent_types:
        raise ValueError("agent type must be Q_Learning, SARSA, Expected_SARSA or MonteCarlo")

    if len(sys.argv) > 2:
        num_simulations = int(sys.argv[2])
    else:
        num_simulations = 1

    env = 'CliffWalking-v1'
    # time limit of a run (CliffWalking-v1 has none)
    max_episode_steps = 100

    agent = Tabular_Simulator(env, agent_type, max_episode_steps)
    agent.load_table(models_path)

    for i in range(num_simulations):
        agent.simulate()
