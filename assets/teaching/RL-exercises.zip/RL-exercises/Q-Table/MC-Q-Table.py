# Reference: R. S. Sutton and A. G. Barto, "Reinforcement Learning: An Introduction", 2nd ed., MIT Press, 2018.
# Every-visit Monte Carlo: Section 5.1; on-policy Monte Carlo control with epsilon-soft policies: Section 5.4
# (the book gives the control algorithm in its first-visit form).

import gymnasium as gym

from abc import ABC, abstractmethod
from tqdm import tqdm
import matplotlib.pyplot as plt

import numpy as np
import os, random

class tabular_agent(ABC):

    def __init__(self, env, epsilon_start, epsilon_decay, epsilon_min, episodes, gamma, max_episode_steps):
        self.env_name = env
        self.max_episode_steps = max_episode_steps
        self.env = gym.make(self.env_name, max_episode_steps = self.max_episode_steps)
        self.epsilon = epsilon_start
        self.epsilon_decay = epsilon_decay
        self.epsilon_min = epsilon_min
        self.episodes = episodes
        self.gamma = gamma
        
        self.action_space = self.env.action_space
        self.action_size = self.env.action_space.n
        self.state_size = self.env.observation_space.n

        # Definition of the Q-table
        self.table = np.zeros((self.state_size, self.action_size))
        self.visits = np.zeros((self.state_size, self.action_size))
        
        
        self.score = []
        self.epsilon_record = []

    def update_epsilon(self):
        if self.epsilon > self.epsilon_min:
            self.epsilon *= self.epsilon_decay

    @abstractmethod
    def update_table(self, trajectory):
        pass
    
    def select_action(self, state): # epsilon-greedy action selection
        if random.random() <= self.epsilon:
            return self.action_space.sample()
            
        return np.argmax(self.table[state, :])

    def learn(self):
        for e in tqdm(np.arange(self.episodes), desc="Learning"):
            state, _ = self.env.reset()
            episode_score = 0
            done = False
            trajectory = []
            
            while not done:
                # choose the next action
                action = self.select_action(state)
                
                # do the chosen action
                next_state, reward, terminated, truncated, _ = self.env.step(action)

                done = terminated or truncated

                # positive terminal state reached (the goal is the only terminal state)
                if terminated:
                    # reward of the goal set to +100 instead of the -1 of gymnasium
                    reward = 100

                episode_score += reward

                trajectory.append((state, action, reward))

                # update the current state
                state = next_state

                if done:
                    self.score.append(episode_score)
                    self.epsilon_record.append(self.epsilon)
                    self.update_epsilon()
                    
                    # learn
                    self.update_table(trajectory)
                    trajectory = []

    def plot_learning(self, N, title=None, filename=""):
        #plt.figure()
        plt.plot(self.score, label = "score");
        if len(self.score) >= N:
            mean_score = np.convolve(np.array(self.score), np.ones(N)/N, mode='valid')
            plt.plot(np.arange(len(mean_score)) + (N - 1) // 2, mean_score, label = "moving average");
        plt.xlabel("episode");
        plt.ylabel("score");
        plt.legend();
        if title is not None:
            plt.title(title);
        plt.savefig(filename + "_" + self.env_name, bbox_inches = "tight");
        plt.clf();

    def plot_epsilon(self, filename = ""):
        plt.plot(self.epsilon_record);
        plt.xlabel("episode");
        plt.title("Epsilon decay");
        plt.savefig(filename + "_" + self.env_name + "_epsilon", bbox_inches = "tight");
        plt.clf();

    def save_table(self, path=""):
        np.save(path + self.env_name + "_" + str(self) + ".npy", self.table)


class MC_Learning(tabular_agent):

    def __init__(self, env, epsilon_start, epsilon_decay, epsilon_min, episodes, gamma, max_episode_steps):
        super().__init__(env, epsilon_start, epsilon_decay, epsilon_min, episodes, gamma, max_episode_steps)

    def update_table(self, trajectory):
        g = 0  # return
        for state, action, reward in reversed(trajectory):
            g = reward + self.gamma * g
            self.visits[state, action] += 1
            self.table[state, action] += (g - self.table[state, action]) / self.visits[state, action]

    def __str__(self):
        return "MonteCarlo"


if __name__ == '__main__':
    env = 'CliffWalking-v1'
    epsilon_start = 1.0
    epsilon_decay = 0.98
    epsilon_min = 0.01
    episodes = 500
    gamma = 0.99
    # time limit of an episode (CliffWalking-v1 has none)
    max_episode_steps = 200
    
    
    agent = MC_Learning(env, epsilon_start, epsilon_decay, epsilon_min, episodes, gamma, max_episode_steps)
    
    os.makedirs("imgs", exist_ok = True)
    os.makedirs("models", exist_ok = True)
    
    agent.learn()
    agent.save_table("models/")
    agent.plot_learning(11, filename = "imgs/" + str(agent))
    agent.plot_epsilon("imgs/" + str(agent))
