# checks the installation: imports the packages, runs a few random steps in each environment
# and reports the device that the exercises will use
# exit code 3: the Intel build of PyTorch is installed, but the Intel GPU is missing or failed the test operations
# (the installer then installs the CPU build)

import os, sys

os.environ.setdefault("PYTORCH_ENABLE_MPS_FALLBACK", "1")

import gymnasium as gym
import numpy as np
import matplotlib
import torch
import torch.nn as nn
from torch.distributions.multivariate_normal import MultivariateNormal
import tqdm
import pygame
import Box2D

print("python     ", sys.version.split()[0])
print("gymnasium  ", gym.__version__)
print("numpy      ", np.__version__)
print("matplotlib ", matplotlib.__version__)
print("torch      ", torch.__version__)
print("tqdm       ", tqdm.__version__)

for env_name, kwargs in [("CliffWalking-v1", {}), ("LunarLander-v3", {}), ("LunarLander-v3", {"continuous": True})]:
	env = gym.make(env_name, **kwargs)
	state, _ = env.reset(seed = 0)
	for t in np.arange(20):
		state, reward, terminated, truncated, _ = env.step(env.action_space.sample())
		if terminated or truncated:
			state, _ = env.reset()
	env.close()
	print("environment", env_name, kwargs if kwargs else "")

# same rule as the exercises: NVIDIA or AMD GPU (cuda), Intel GPU (xpu), Apple silicon GPU (mps), otherwise the CPU
if torch.cuda.is_available():
	device = "cuda:0"
elif torch.xpu.is_available():
	device = "xpu"
elif torch.backends.mps.is_available():
	device = "mps"
else:
	device = "cpu"

# Intel build of PyTorch without a usable Intel GPU (for example, no Intel GPU driver): the CPU build is smaller
if getattr(torch.version, "xpu", None) and device == "cpu":
	print("device      cpu: the Intel build of PyTorch is installed, but no Intel GPU is usable")
	sys.exit(3)

# the operations of the exercises: layers with backpropagation, gradients, gaussian distributions
try:
	layer = nn.Linear(8, 2).to(device)
	means = layer(torch.randn((4, 8)).to(device))
	m = MultivariateNormal(means, torch.eye(2).to(device))
	m.log_prob(m.sample()).sum().backward()
	torch.autograd.grad(layer(torch.randn(8).to(device))[0], layer.parameters())
	x = torch.ones((64, 64)).to(device)
	assert float((x @ x).sum()) == 64.0 ** 3
except Exception as error:
	print("device     ", device, "FAILED:", error)
	sys.exit(3 if device == "xpu" else 1)

print("device     ", device, "(" + torch.cuda.get_device_name(0) + ")" if device == "cuda:0" else "")

print("Installation OK")
