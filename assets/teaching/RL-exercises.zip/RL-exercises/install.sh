#!/bin/sh
# installs uv, Python 3.13 (only if missing) and the packages of requirements.txt
# in a virtual environment .venv inside this folder; nothing is installed elsewhere

set -e
cd "$(dirname "$0")"

TOOLS="$PWD/.tools"
export UV_PYTHON_INSTALL_DIR="$TOOLS/python"
export UV_CACHE_DIR="$TOOLS/cache"
# trust the certificates of the operating system (needed behind university or company proxies)
export UV_SYSTEM_CERTS=true
UV="$TOOLS/uv/uv"

# uv: installer of Python and of the packages
if [ ! -x "$UV" ]; then
	if command -v curl > /dev/null 2>&1; then
		curl -LsSf https://astral.sh/uv/0.13.0/install.sh | env UV_UNMANAGED_INSTALL="$TOOLS/uv" sh
	else
		wget -qO- https://astral.sh/uv/0.13.0/install.sh | env UV_UNMANAGED_INSTALL="$TOOLS/uv" sh
	fi
fi

# virtual environment with Python 3.13 (downloaded if not available on the machine)
# (kept if it exists, so that the script can be run again after a failure)
if [ ! -d .venv ]; then
	"$UV" venv --python 3.13 .venv
fi

# packages; PyTorch is chosen for the GPU of the machine (CPU build if there is none)
if ! "$UV" pip install --python .venv -r requirements.txt --torch-backend=auto; then
	echo "The GPU build of PyTorch could not be installed: installing the CPU build."
	"$UV" pip install --python .venv -r requirements.txt --torch-backend=cpu --reinstall-package torch
fi

status=0
.venv/bin/python check_installation.py || status=$?

# exit code 3: the Intel build of PyTorch cannot use the Intel GPU; a new environment with the CPU build
# replaces it, and the cache, which holds the Intel build, is emptied
if [ "$status" -eq 3 ]; then
	echo "The Intel GPU cannot be used: installing the CPU build of PyTorch."
	rm -rf .venv
	"$UV" venv --python 3.13 .venv
	"$UV" pip install --python .venv -r requirements.txt --torch-backend=cpu
	"$UV" cache clean
	.venv/bin/python check_installation.py
elif [ "$status" -ne 0 ]; then
	exit "$status"
fi
