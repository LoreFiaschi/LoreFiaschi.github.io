# Reinforcement learning exercises

## Structure

| Folder | Algorithms | Environment | Solution | Exercise | Viewer |
|---|---|---|---|---|---|
| `Q-Table/` | Q-learning, SARSA, Expected SARSA | `CliffWalking-v1` | `Q-Table.py` | `Q-Table_exercise.py` | `Q-Table_simulator.py` |
| `Q-Table/` | Monte Carlo control | `CliffWalking-v1` | `MC-Q-Table.py` | `MC-Q-Table_exercise.py` | `Q-Table_simulator.py` |
| `DQN/` | double DQN, dueling double DQN | `LunarLander-v3`, discrete | `DQL.py` | `DQL_exercise.py` | `DQL_simulator.py` |
| `PG/` | REINFORCE | `LunarLander-v3`, continuous | `reinforce.py` | `reinforce_exercise.py` | `reinforce_simulator.py` |
| `DPG/` | COPDAC-GQ (deterministic policy gradient) | `LunarLander-v3`, continuous | `DPG.py` | `DPG_exercise.py` | `DPG_simulator.py` |
| `DDPG/` | DDPG | `LunarLander-v3`, continuous | `DDPG.py` | `DDPG_exercise.py` | `DDPG_simulator.py` |

- Every folder has `imgs/` (plots) and `models/` (the trained Q-tables in `Q-Table/`, the trained weights elsewhere).
- The first lines of each file give the reference papers.
- `install.bat`, `install.ps1`: installation on Windows. `install.sh`: installation on macOS and Linux.
- `requirements.txt`: packages and versions. `check_installation.py`: installation test.

## Prerequisites

- Windows 10 or 11 (64 bit), macOS on Apple silicon, or Linux (x86-64). PyTorch has no packages for Intel Macs.
- Internet connection. Python is not needed; no administrator rights are needed.
- Free disk space: about 1 GB without a GPU, a few GB with a GPU (the GPU builds of PyTorch are larger).

## Installation

- Windows: double-click `install.bat`.
- macOS, Linux: in a terminal, in this folder, run `sh install.sh`.

The script:

1. downloads `uv` (Python and package installer) into `.tools/`;
2. creates the virtual environment `.venv` with Python 3.13, downloading Python if it is missing;
3. installs `requirements.txt`; PyTorch matches the GPU of the machine (NVIDIA, AMD on Linux, Intel),
   or is the CPU build if there is no GPU;
4. runs `check_installation.py`, which ends with `Installation OK` and prints the device in use.
   If the Intel build of PyTorch was installed but the Intel GPU cannot be used (no driver, or a failed test),
   the script replaces it with the CPU build and runs the test again.

Everything stays inside this folder. To uninstall, delete the folder.

### Notice for the GPU

The GPU is used only if its driver is installed before the installer runs. A GPU is optional:
every exercise also runs on the CPU, and the tabular exercises (`Q-Table/`) always use the CPU.

If the check prints `device cpu` on a machine with a GPU:

1. install the driver of the GPU, as below;
2. restart the computer;
3. delete the folder `.venv` and run the installer again.

**NVIDIA GPU**

- Windows: download the driver for your GPU from https://www.nvidia.com/drivers (or install the
  NVIDIA App) and run it.
- Linux (Ubuntu, Linux Mint and derivatives): open *Additional Drivers* (Ubuntu) or
  *Driver Manager* (Linux Mint) and choose the recommended `nvidia-driver` package, or run
  `sudo ubuntu-drivers install` in a terminal. The open-source driver `nouveau`, installed by
  default, is not enough.
- Linux, other distributions: install the NVIDIA driver from the packages of the distribution
  (for example `akmod-nvidia` from RPM Fusion on Fedora, `nvidia-open` on Arch Linux).
- Check: `nvidia-smi` in a terminal shows the GPU.

**AMD GPU** (Linux only; on Windows the exercises use the CPU)

- Install ROCm as described at https://rocm.docs.amd.com/projects/install-on-linux/en/latest/
  (the page lists the supported GPUs).
- Check: `rocminfo` in a terminal lists the GPU.

**Intel GPU** (Intel Arc graphics, and Intel Core Ultra processors with Intel Arc graphics; older
integrated graphics, such as Intel Iris Xe and Intel UHD, are not supported by PyTorch and use the CPU)

- Windows 11: install the latest Intel Arc graphics driver from https://www.intel.com/content/www/us/en/download-center/home.html
  (or with the Intel Driver & Support Assistant).
- Linux (Ubuntu 24.04 and derivatives): follow the Linux part of
  https://www.intel.com/content/www/us/en/developer/articles/tool/pytorch-prerequisites-for-intel-gpu.html

**Apple silicon (M1 and later):** nothing to install; the GPU is used through macOS.

## Running an exercise

1. Activate the environment, in this folder:
   - Windows, Command Prompt: `.venv\Scripts\activate`
   - macOS, Linux: `source .venv/bin/activate`
2. Enter the exercise folder: `cd DQN`.
3. Complete the lines of the exercise file that raise `NotImplementedError`; each has a `TODO` comment.
4. Train: `python DQL_exercise.py`.
5. Watch the trained agent: `python DQL_simulator.py`.

| Folder | Train | Watch (optional number of runs) |
|---|---|---|
| `Q-Table/` | `python Q-Table_exercise.py`, `python MC-Q-Table_exercise.py` | `python Q-Table_simulator.py Q_Learning 3` (or `SARSA`, `Expected_SARSA`, `MonteCarlo`) |
| `DQN/` | `python DQL_exercise.py` (double DQN) or `python DQL_exercise.py DDDQN` (dueling) | `python DQL_simulator.py DDQN 3` |
| `PG/` | `python reinforce_exercise.py` | `python reinforce_simulator.py 3` |
| `DPG/` | `python DPG_exercise.py` | `python DPG_simulator.py 3` |
| `DDPG/` | `python DDPG_exercise.py` | `python DDPG_simulator.py 3` |

- In `Q-Table_exercise.py`, choose the agent in the block `if __name__ == '__main__':`.
- Hyperparameters are in the same block of each file.
- The programs use the GPU when there is one (NVIDIA, AMD on Linux, Intel or Apple silicon), otherwise the CPU.
  If the Intel GPU fails a test operation at start-up, the program uses the CPU.
