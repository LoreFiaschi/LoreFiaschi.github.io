@echo off
rem runs install.ps1; the execution policy is relaxed for this run only
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
pause
