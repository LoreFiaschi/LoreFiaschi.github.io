# installs uv, Python 3.13 (only if missing) and the packages of requirements.txt
# in a virtual environment .venv inside this folder; nothing is installed elsewhere

$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

$tools = Join-Path $PSScriptRoot ".tools"
$env:UV_PYTHON_INSTALL_DIR = Join-Path $tools "python"
$env:UV_CACHE_DIR = Join-Path $tools "cache"
# trust the certificates of the operating system (needed behind university or company proxies)
$env:UV_SYSTEM_CERTS = "true"
$uv = Join-Path $tools "uv\uv.exe"
$python = Join-Path $PSScriptRoot ".venv\Scripts\python.exe"

# uv: installer of Python and of the packages
if (-not (Test-Path $uv)) {
	$env:UV_UNMANAGED_INSTALL = Join-Path $tools "uv"
	powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; irm https://astral.sh/uv/0.13.0/install.ps1 | iex"
	if ($LASTEXITCODE -ne 0) { throw "uv installation failed" }
}

# virtual environment with Python 3.13 (downloaded if not available on the machine)
# (kept if it exists, so that the script can be run again after a failure)
if (-not (Test-Path (Join-Path $PSScriptRoot ".venv"))) {
	& $uv venv --python 3.13 .venv
	if ($LASTEXITCODE -ne 0) { throw "creation of the virtual environment failed" }
}

# packages; PyTorch is chosen for the GPU of the machine (CPU build if there is none)
& $uv pip install --python .venv -r requirements.txt --torch-backend=auto
if ($LASTEXITCODE -ne 0) {
	Write-Host "The GPU build of PyTorch could not be installed: installing the CPU build."
	& $uv pip install --python .venv -r requirements.txt --torch-backend=cpu --reinstall-package torch
	if ($LASTEXITCODE -ne 0) { throw "installation of the packages failed" }
}

& $python check_installation.py

# exit code 3: the Intel build of PyTorch cannot use the Intel GPU; a new environment with the CPU build
# replaces it, and the cache, which holds the Intel build, is emptied
if ($LASTEXITCODE -eq 3) {
	Write-Host "The Intel GPU cannot be used: installing the CPU build of PyTorch."
	Remove-Item -Recurse -Force (Join-Path $PSScriptRoot ".venv")
	& $uv venv --python 3.13 .venv
	if ($LASTEXITCODE -ne 0) { throw "creation of the virtual environment failed" }
	& $uv pip install --python .venv -r requirements.txt --torch-backend=cpu
	if ($LASTEXITCODE -ne 0) { throw "installation of the CPU build failed" }
	& $uv cache clean
	if ($LASTEXITCODE -ne 0) { throw "cleaning of the cache failed" }
	& $python check_installation.py
}
if ($LASTEXITCODE -ne 0) { throw "installation check failed" }
