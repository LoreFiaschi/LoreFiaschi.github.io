# Reference: D. Silver, G. Lever, N. Heess, T. Degris, D. Wierstra, M. Riedmiller,
# "Deterministic Policy Gradient Algorithms", ICML 2014.
# COPDAC-GQ: Section 4.3, Eqs. 23-27; compatible features: Theorem 3 and p. 5.

import gymnasium as gym
import numpy as np
import matplotlib.pyplot as plt
from tqdm import tqdm
import os

# on Apple silicon, the operations that the GPU does not support run on the CPU
os.environ.setdefault("PYTORCH_ENABLE_MPS_FALLBACK", "1")

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.utils import parameters_to_vector, vector_to_parameters

from multiprocessing import cpu_count

######## SET DEVICE ######################
# use the GPU when available: NVIDIA or AMD (cuda), Intel (xpu) or Apple silicon (mps), otherwise the CPU
if torch.cuda.is_available():
	device = "cuda:0"
elif torch.xpu.is_available():
	device = "xpu"
elif torch.backends.mps.is_available():
	device = "mps"
else:
	device = "cpu"

# back to the CPU if the Intel GPU cannot run the operations of the exercise
if device == "xpu":
	try:
		layer = nn.Linear(8, 2).to(device)
		torch.autograd.grad(layer(torch.randn(8).to(device))[0], layer.parameters())
	except Exception:
		print("the Intel GPU failed a test operation: the CPU is used instead")
		device = "cpu"
#########################################


class Actor_Network(nn.Module):

	def __init__(self, in_size, out_size, hidden = 64):
		super().__init__()
		self.layer1 = nn.Linear(in_size, hidden)
		self.layer2 = nn.Linear(hidden, hidden)
		self.layer3 = nn.Linear(hidden, out_size)

	def forward(self, x):
		x = F.relu(self.layer1(x))
		x = F.relu(self.layer2(x))
		# actions in [-1, 1]
		return torch.tanh(self.layer3(x))


class DPGA_COPDAC_GQ():

	def __init__(self, env, network, episodes, gamma, sigma_beta, alpha_theta, alpha_w, alpha_v, alpha_u, early_stopping_window, threshold):
		self.env_name = env
		self.env = gym.make(self.env_name, continuous = True)
		self.action_size = self.env.action_space.shape[0]
		self.state_size = self.env.observation_space.shape[0]

		# actor
		self.model = network(self.state_size, self.action_size).to(device)
		self.n_parameters = sum(p.numel() for p in self.model.parameters())

		self.episodes = episodes
		self.gamma = gamma
		self.sigma_beta = sigma_beta
		self.alpha_theta = alpha_theta
		self.alpha_w = alpha_w
		self.alpha_v = alpha_v
		self.alpha_u = alpha_u
		self.early_stopping_window = early_stopping_window
		self.threshold = threshold

		self.score = []

		# critic: weights w of the advantage, weights v of the baseline, weights u of the gradient correction
		self.w = torch.zeros(self.n_parameters).to(device)
		self.v = torch.zeros(self.state_size + 1).to(device)
		self.u = torch.zeros(self.n_parameters).to(device)


	def select_action(self, state):
		with torch.no_grad():
			raise NotImplementedError # TODO deterministic action of the actor
			raise NotImplementedError # TODO exploration noise
		# the actions of LunarLander lie in [-1, 1]
		return torch.clamp(action, -1, 1)


	def state_features(self, state):
		# the state and a constant feature
		return torch.cat((state, torch.ones(1).to(device)))


	def jacobian(self, state):
		mu = self.model(state.unsqueeze(0)).squeeze(0)
		J = torch.empty((self.action_size, self.n_parameters)).to(device)
		# one backward pass for each action component: row i is the gradient of mu_i with respect to the actor parameters
		for i in np.arange(self.action_size):
			grads = torch.autograd.grad(mu[i], self.model.parameters(), retain_graph = True)
			J[i, :] = torch.cat([g.flatten() for g in grads])
		return mu.detach(), J


	def critic(self, mu, J, state, action, next_state, done):
		raise NotImplementedError # TODO compatible features

		# features of the baseline, zero at a terminal arrival state
		phi_s = self.state_features(state)
		if done:
			phi_next_s = torch.zeros(self.state_size + 1).to(device)
		else:
			phi_next_s = self.state_features(next_state)

		raise NotImplementedError # TODO q value according to the critic

		raise NotImplementedError # TODO q value of the arrival state according to the critic

		return phi_sa, phi_s, phi_next_s, q, q_next


	def update(self, state, action, reward, next_state, done):
		# output of the actor and its jacobian with respect to the actor parameters
		mu, J = self.jacobian(state)

		phi_sa, phi_s, phi_next_s, q, q_next = self.critic(mu, J, state, action, next_state, done)

		raise NotImplementedError # TODO TD error

		# the updates below use the values of theta, w, v and u before the step

		with torch.no_grad():
			raise NotImplementedError # TODO deterministic policy gradient update of the actor

		raise NotImplementedError # TODO gradient Q-learning update of the critic

		# simultaneous update of the actor and the critic
		vector_to_parameters(theta, self.model.parameters())
		self.w, self.v, self.u = w, v, u


	def learn(self):
		bar = tqdm(np.arange(self.episodes), desc="Learning")
		for e in bar:

			if len(self.score) >= self.early_stopping_window and np.mean(self.score[-self.early_stopping_window:]) >= self.threshold:
				break

			state, _ = self.env.reset()
			# gymnasium gives 0.4 times the angular velocity: the factor converts it to rad/s
			state[5] *= 2.5
			state = torch.tensor(state).to(device)
			episode_score = 0.0
			done = False

			while not done:

				# choose the action with the behaviour policy
				action = self.select_action(state)

				# do the chosen action
				next_state, reward, terminated, truncated, _ = self.env.step(action.cpu().numpy())

				done = terminated or truncated

				# gymnasium gives 0.4 times the angular velocity: the factor converts it to rad/s
				next_state[5] *= 2.5
				next_state = torch.tensor(next_state).to(device)

				episode_score += reward

				# learn from the transition; bootstrapping stops only at a terminal state
				self.update(state, action, reward, next_state, terminated)

				state = next_state

			self.score.append(episode_score)
			bar.set_postfix({'Score': f'{episode_score:.0f}'})

		self.env.close()


	def plot_learning(self, N, title = None, filename = ""):
		plt.plot(self.score, label = "score")
		# moving average over N episodes, centred on each window
		if len(self.score) >= N:
			mean_score = np.convolve(np.array(self.score), np.ones(N)/N, mode = 'valid')
			plt.plot(np.arange(len(mean_score)) + (N - 1) // 2, mean_score, label = "moving average")
		plt.xlabel("episode")
		plt.ylabel("score")
		plt.legend()

		if title is not None:
			plt.title(title)

		plt.savefig(filename + "_" + self.env_name)
		plt.clf()


	def save_model(self, path = ""):
		torch.save(self.model.state_dict(), path + self.env_name + "_" + str(self) + ".pt")
		torch.save({'w': self.w, 'v': self.v, 'u': self.u}, path + self.env_name + "_" + str(self) + "_critic.pt")


	def __str__(self):
		return "COPDAC_GQ"


if __name__ == '__main__':

	######## SET PARALLEL COMPUTING ##########
	num_cores = cpu_count()

	torch.set_num_interop_threads(num_cores) # Inter-op parallelism
	torch.set_num_threads(num_cores) # Intra-op parallelism
	##########################################

	env = 'LunarLander-v3'
	network = Actor_Network
	episodes = 1000
	gamma = 0.99
	sigma_beta = 0.2
	# the critic must learn on a faster time scale than the actor (Silver et al. 2014, p. 6)
	alpha_theta = 1e-5
	alpha_w = 1e-3
	alpha_v = 1e-3
	alpha_u = 1e-3
	early_stopping_window = 100
	threshold = 200
	imgs_path = "imgs/"
	models_path = "models/"

	os.makedirs(imgs_path, exist_ok = True)
	os.makedirs(models_path, exist_ok = True)

	agent = DPGA_COPDAC_GQ(env, network, episodes, gamma, sigma_beta, alpha_theta, alpha_w, alpha_v, alpha_u, early_stopping_window, threshold)

	agent.learn()
	agent.save_model(models_path)
	agent.plot_learning(31, title = "Lunar Lander", filename = imgs_path + str(agent))
