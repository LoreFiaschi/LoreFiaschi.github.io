# Reference: D. Silver, G. Lever, N. Heess, T. Degris, D. Wierstra, M. Riedmiller,
# "Deterministic Policy Gradient Algorithms", ICML 2014.
# COPDAC-GQ: Section 4.3, Eqs. 23-27; compatible features: Theorem 3 and p. 5.

import sys

from DPG import Actor_Network, torch, gym, device


class DPGAS():

	def __init__(self, env_name, network):
		self.env_name = env_name
		self.env = gym.make(self.env_name, continuous = True)
		self.action_size = self.env.action_space.shape[0]
		self.state_size = self.env.observation_space.shape[0]
		self.env.close()

		self.model = network(self.state_size, self.action_size).to(device)


	def select_action(self, state):
		# deterministic action of the actor, without exploration noise
		with torch.no_grad():
			return self.model(state.unsqueeze(0)).squeeze(0)


	def load_model(self, path = ""):
		self.model.load_state_dict(torch.load(path + self.env_name + "_COPDAC_GQ.pt", map_location = torch.device(device)))
		self.model.eval()


	def simulate(self):
		env = gym.make(self.env_name, continuous = True, render_mode = "human")
		done = False
		state, _ = env.reset()
		# gymnasium gives 0.4 times the angular velocity: the factor converts it to rad/s
		state[5] *= 2.5
		state = torch.tensor(state).to(device)
		while not done:
			action = self.select_action(state)
			next_state, _, terminated, truncated, _ = env.step(action.cpu().numpy())

			done = terminated or truncated

			# gymnasium gives 0.4 times the angular velocity: the factor converts it to rad/s
			next_state[5] *= 2.5
			state = torch.tensor(next_state).to(device)

		env.close()


if __name__ == '__main__':

	env = 'LunarLander-v3'
	network = Actor_Network
	models_path = "models/"

	if len(sys.argv) > 1:
		num_simulations = int(sys.argv[1])
	else:
		num_simulations = 1

	agent = DPGAS(env, network)
	agent.load_model(models_path)

	for i in range(num_simulations):
		agent.simulate()
