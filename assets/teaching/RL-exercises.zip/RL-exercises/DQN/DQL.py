# References:
# H. van Hasselt, A. Guez, D. Silver, "Deep Reinforcement Learning with Double Q-learning", AAAI 2016 (arXiv:1509.06461).
# Double DQN target: section "Double DQN", p. 4.
# Z. Wang, T. Schaul, M. Hessel, H. van Hasselt, M. Lanctot, N. de Freitas,
# "Dueling Network Architectures for Deep Reinforcement Learning", ICML 2016 (arXiv:1511.06581).
# Dueling network (DDDQN): Section 3, Eq. (9).

import gymnasium as gym
import random
import numpy as np
import matplotlib.pyplot as plt
from tqdm import tqdm
from collections import deque
from abc import ABC, abstractmethod
import os, sys

# on Apple silicon, the operations that the GPU does not support run on the CPU
os.environ.setdefault("PYTORCH_ENABLE_MPS_FALLBACK", "1")

import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F

from multiprocessing import cpu_count

######## SET DEVICE ######################
# use the GPU when available: NVIDIA or AMD (cuda), Intel (xpu) or Apple silicon (mps), otherwise the CPU
if torch.cuda.is_available():
	device = "cuda:0"
elif torch.xpu.is_available():
	device = "xpu"
elif torch.backends.mps.is_available():
	device = "mps"
else:
	device = "cpu"

# back to the CPU if the Intel GPU cannot run the operations of the exercise
if device == "xpu":
	try:
		layer = nn.Linear(8, 2).to(device)
		layer(torch.randn((4, 8)).to(device)).pow(2).mean().backward()
	except Exception:
		print("the Intel GPU failed a test operation: the CPU is used instead")
		device = "cpu"
#########################################


class Q_Network(nn.Module):

	def __init__(self, n_observations, n_actions, hidden = 64):
		super().__init__()
		self.layer1 = nn.Linear(n_observations, hidden)
		self.layer2 = nn.Linear(hidden, hidden)
		self.layer3 = nn.Linear(hidden, n_actions)

	def forward(self, x):
		x = F.relu(self.layer1(x))
		x = F.relu(self.layer2(x))
		return self.layer3(x)


class Dueling_Network(nn.Module):

	def __init__(self, n_observations, n_actions, hidden = 64):
		super().__init__()
		self.layer1 = nn.Linear(n_observations, hidden)
		self.layer2 = nn.Linear(hidden, hidden)

		self.V = nn.Linear(hidden, 1)

		self.A = nn.Linear(hidden, n_actions)
		
	def forward(self, x):
		x = F.relu(self.layer1(x))
		x = F.relu(self.layer2(x))
		V = self.V(x)
		A = self.A(x)

		return V + (A - A.mean(dim=1, keepdim=True))


class DeepAgent(ABC):

	def __init__(self, env, epsilon_start, epsilon_decay, epsilon_min, episodes, gamma, learning_rate, batch_size, train_start, 
					replay_frequency, target_model_update_rate, memory_length, mini_batches, agent_type, early_stopping_window, threshold):
		self.env_name = env
		self.env = gym.make(self.env_name)
		self.epsilon = epsilon_start
		self.epsilon_decay = epsilon_decay
		self.epsilon_min = epsilon_min
		self.episodes = episodes
		self.gamma = gamma
		self.replay_frequency = replay_frequency
		self.target_model_update_rate = target_model_update_rate
		self.mini_batches = mini_batches
		self.score = []
		self.epsilon_record = []
		self.early_stopping_window = early_stopping_window
		self.threshold = threshold
		
		self.action_space = self.env.action_space
		self.action_size = self.env.action_space.n
		self.state_size = self.env.observation_space.shape[0]
		
		
		self.learning_rate = learning_rate
		self.batch_size = batch_size
		self.train_start = train_start
		
		self.memory = deque(maxlen=memory_length)
		
		self.agent_type = agent_type
		
		if self.agent_type == "DDDQN":
			self.model = Dueling_Network(self.state_size, self.action_size)
			self.target_model = Dueling_Network(self.state_size, self.action_size)
		else:
			self.model = Q_Network(self.state_size, self.action_size)
			self.target_model = Q_Network(self.state_size, self.action_size)

		self.model = self.model.to(device)
		self.target_model = self.target_model.to(device)

		self.target_model.load_state_dict(self.model.state_dict())
		self.model.eval()
		self.target_model.eval()
		
		self.criterion = nn.SmoothL1Loss()
		self.optimizer = optim.AdamW(self.model.parameters(), lr = learning_rate, amsgrad=True)

		self.state_batch = torch.empty((self.batch_size, self.state_size)).to(device)
		self.next_state_batch = torch.empty((self.batch_size, self.state_size)).to(device)
		self.action_batch = torch.empty((self.batch_size, 1), dtype = torch.long).to(device)
		self.reward_batch = torch.empty((self.batch_size,1)).to(device)
		self.not_done_batch = torch.empty(self.batch_size, dtype = torch.bool).to(device)
		
		
	def update_epsilon(self):
		if len(self.memory) >= self.train_start and self.epsilon > self.epsilon_min:
			self.epsilon *= self.epsilon_decay
		
			
	def add_experience(self, state, action, reward, next_state, done):
		self.memory.append((state, action, reward, next_state, done))


	def select_action(self, state):
		if random.random() <= self.epsilon:
			return self.action_space.sample()
		
		with torch.no_grad():
			return torch.argmax(self.model(state.unsqueeze(0))).item()


	def update_target_model(self, tau):
		weights = self.model.state_dict()
		target_weights = self.target_model.state_dict()
		for i in target_weights:
			target_weights[i] = weights[i] * tau + target_weights[i] * (1-tau)
		self.target_model.load_state_dict(target_weights)
	
	
	@abstractmethod
	def q_value_arrival_state(self, states):
		pass
	
	
	def experience_replay(self):
		if len(self.memory) < self.train_start:
			return
		
		batch = random.sample(self.memory, self.batch_size)
		
		for i in np.arange(self.batch_size):
			self.state_batch[i,:] = batch[i][0]
			self.action_batch[i,0] = batch[i][1]
			self.reward_batch[i,0] = batch[i][2]
			self.next_state_batch[i,:] = batch[i][3]
			self.not_done_batch[i] = not batch[i][4]
			
		self.next_state_values = torch.zeros((self.batch_size,1)).to(device)
		
		with torch.no_grad():
			self.next_state_values[self.not_done_batch] = self.q_value_arrival_state(self.next_state_batch[self.not_done_batch,:])
			target_values = self.reward_batch + self.gamma * self.next_state_values

		self.model.train()

		predicted_values = self.model(self.state_batch).gather(1,self.action_batch)

		loss = self.criterion(predicted_values, target_values)
		
		self.optimizer.zero_grad()
		loss.backward()
		self.optimizer.step()
		
		self.model.eval()
		
		
	def learn(self):
		bar = tqdm(np.arange(self.episodes), desc="Learning")
		for e in bar:
		
			if len(self.score) >= self.early_stopping_window and np.mean(self.score[-self.early_stopping_window:]) >= self.threshold:
				break
			
			state, _ = self.env.reset()
			# gymnasium gives 0.4 times the angular velocity: the factor converts it to rad/s
			state[5] *= 2.5
			state = torch.tensor(state).to(device)
			episode_score = 0
			step = 0
			done = False
						
			while not done:
				
				action = self.select_action(state)

				next_state, reward, terminated, truncated, _ = self.env.step(action)
				
				done = terminated or truncated
				
				# gymnasium gives 0.4 times the angular velocity: the factor converts it to rad/s
				next_state[5] *= 2.5
				next_state = torch.tensor(next_state).to(device)

				episode_score += reward
				reward = torch.tensor(reward, dtype = torch.float32).to(device)
				
				self.add_experience(state, action, reward, next_state, terminated)
				
				state = next_state
				
				if step % self.replay_frequency == 0:
					for i in np.arange(self.mini_batches):
						self.experience_replay()
						self.update_target_model(self.target_model_update_rate)
				
				step += 1

				if done:								
					self.update_epsilon()
					self.score.append(episode_score)
					self.epsilon_record.append(self.epsilon)

			bar.set_postfix({'Score': f'{self.score[-1]:.0f}'})
					
		self.env.close()
		
		
	def plot_learning(self, N, title=None, filename = ""):
		plt.plot(self.score, label = "score")
		if len(self.score) >= N:
			mean_score = np.convolve(np.array(self.score), np.ones(N)/N, mode='valid')
			plt.plot(np.arange(len(mean_score)) + (N-1)//2, mean_score, label = "moving average")
		plt.xlabel("episode")
		plt.ylabel("score")
		plt.legend()

		if title is not None:
			plt.title(title);

		plt.savefig(filename + self.env_name)
		plt.clf()


	def plot_epsilon(self, filename = ""):
		plt.plot(self.epsilon_record);
		plt.xlabel("episode")
		plt.title("Epsilon decay");
		plt.savefig(filename + self.env_name + "_epsilon")
		plt.clf()
		
	
	def save_model(self, path=""):
		torch.save(self.model.state_dict(), path+self.env_name+"_"+self.agent_type+".pt")

	
	def load_model(self, path):
		self.model.load_state_dict(torch.load(path+self.env_name+"_"+self.agent_type+".pt", map_location=torch.device(device)))
		self.model.eval()
		


class DDQNA(DeepAgent):
	
	def __init__(self, env, epsilon_start, epsilon_decay, epsilon_min, episodes, gamma, learning_rate, batch_size, train_start, 
					replay_frequency, target_model_update_rate, memory_length, mini_batches, agent_type, early_stopping_window, threshold):
		super().__init__(env, epsilon_start, epsilon_decay, epsilon_min, episodes, gamma, learning_rate, batch_size, train_start,
						 replay_frequency, target_model_update_rate, memory_length, mini_batches, agent_type, early_stopping_window, threshold)
	
	
	def q_value_arrival_state(self, states):
		actions = torch.argmax(self.model(states), dim = 1).unsqueeze(1)
		return self.target_model(states).gather(1, actions)

	

if __name__ == '__main__':

	######## SET PARALLEL COMPUTING ##########
	num_cores = cpu_count()

	torch.set_num_interop_threads(num_cores) # Inter-op parallelism
	torch.set_num_threads(num_cores) # Intra-op parallelism
	##########################################

	env = 'LunarLander-v3'
	if len(sys.argv) > 1:
		agent_type = sys.argv[1] # "DDDQN" or "DDQN"
	else:
		agent_type = "DDQN"

	if agent_type not in ["DDQN", "DDDQN"]:
		raise ValueError("agent type must be DDQN or DDDQN")

	episodes = 800
	replay_frequency = 4
	gamma = 0.99
	learning_rate = 5e-4
	epsilon_start = 1
	epsilon_decay = 0.988
	epsilon_min = 0.01
	batch_size = 256
	train_start = 2000
	target_model_update_rate = 1e-3
	memory_length = 20000
	mini_batches = 4
	early_stopping_window = 100
	threshold = 220

	imgs_path = "imgs/"
	models_path = "models/"

	os.makedirs(imgs_path, exist_ok = True)
	os.makedirs(models_path, exist_ok = True)

	agent = DDQNA(env, epsilon_start, epsilon_decay, epsilon_min, episodes, gamma, learning_rate, batch_size, train_start,
				replay_frequency, target_model_update_rate, memory_length, mini_batches, agent_type, early_stopping_window, threshold)
	
	agent.learn()
	agent.save_model(models_path)
	agent.plot_learning(31, title = "Lunar Lander", filename = imgs_path + agent_type + "_")
	agent.plot_epsilon(imgs_path + agent_type + "_")
