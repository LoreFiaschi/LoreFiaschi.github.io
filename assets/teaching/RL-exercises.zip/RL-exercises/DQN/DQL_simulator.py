# References:
# H. van Hasselt, A. Guez, D. Silver, "Deep Reinforcement Learning with Double Q-learning", AAAI 2016 (arXiv:1509.06461).
# Double DQN target: section "Double DQN", p. 4.
# Z. Wang, T. Schaul, M. Hessel, H. van Hasselt, M. Lanctot, N. de Freitas,
# "Dueling Network Architectures for Deep Reinforcement Learning", ICML 2016 (arXiv:1511.06581).
# Dueling network (DDDQN): Section 3, Eq. (9).

import gymnasium as gym
import sys

from DQL import torch, Q_Network, Dueling_Network
from DQL import device
		
		
class DQLAS():

	def __init__(self, env_name, agent_type):
		self.env_name = env_name
		self.env = gym.make(self.env_name)
		self.action_space = self.env.action_space
		self.action_size = self.env.action_space.n
		self.state_size = self.env.observation_space.shape[0]
		self.env.close()
		self.agent_type = agent_type
		
		if self.agent_type == "DDDQN":
			self.model = Dueling_Network(self.state_size, self.action_size).to(device)
		else:
			self.model = Q_Network(self.state_size, self.action_size).to(device)
			
	def select_action(self, state):		
		with torch.no_grad():
			return torch.argmax(self.model(state.unsqueeze(0))).item()
			
	
	def load_model(self, path=""):
		self.model.load_state_dict(torch.load(path + self.env_name + "_" + self.agent_type +".pt", map_location=torch.device(device)))
		self.model.eval()


	def simulate(self):
		env = gym.make(self.env_name, render_mode = "human")
		done = False
		state, _ = env.reset()
		# gymnasium gives 0.4 times the angular velocity: the factor converts it to rad/s
		state[5] *= 2.5
		state = torch.tensor(state).to(device)
		while not done:
			action = self.select_action(state)
			next_state, _, terminated, truncated, _ = env.step(action)

			done = terminated or truncated

			# gymnasium gives 0.4 times the angular velocity: the factor converts it to rad/s
			next_state[5] *= 2.5
			state = torch.tensor(next_state).to(device)

		env.close()


if __name__ == '__main__':
	
	models_path = "models/"
		
	if len(sys.argv) > 1:
		agent_type = sys.argv[1]
	else:
		agent_type = "DDQN"

	if agent_type not in ["DDQN", "DDDQN"]:
		raise ValueError("agent type must be DDQN or DDDQN")
		
	if len(sys.argv) > 2:
		num_simulations = int(sys.argv[2])
	else:
		num_simulations = 1
	
	env = 'LunarLander-v3'

	agent = DQLAS(env, agent_type)
	agent.load_model(models_path)
	
	for i in range(num_simulations):
		agent.simulate()
